from sqlalchemy import Column, Integer, String, Text
from database import Base
from datetime import datetime


class CV(Base):
    __tablename__ = 'cvs'

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    owner_id = Column(Integer, nullable=False)
    skills = Column(Text)
    experience = Column(Text)
    education = Column(Text)
    certifications = Column(Text, nullable=True)
    languages = Column(Text, nullable=True)
    projects = Column(Text, nullable=True)
    layout = Column(String, nullable=True)
    text = Column(Text, nullable=True)  # Colonne réelle pour stocker le texte généré
    created_at = Column(String, default=datetime.utcnow)
    updated_at = Column(String, default=datetime.utcnow, onupdate=datetime.utcnow)
    file_path = Column(String, nullable=True)
