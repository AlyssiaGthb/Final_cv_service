from fastapi import APIRouter, HTTPException, Depends, Header, File, UploadFile, status
from sqlalchemy.orm import Session
from schemas import CVCreate, CVCustomize, CVPreview, CVSave, CVDownload
from models import CV
from database import get_db
from utils import verify_user_exists
import os
import shutil
from pathlib import Path
from PyPDF2 import PdfReader


router=APIRouter()


UPLOAD_DIR = "./uploaded_cvs"

# Assurez-vous que le répertoire existe
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)


@router.post("/upload-cv")
async def upload_cv(
    file: UploadFile = File(...),
    authorization: str = Header(...),
):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    # Vérification de l'extension du fichier
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    try:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        return {"message": "File uploaded successfully", "file_path": file_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


@router.post("/extract-cv")
async def extract_cv_text(
    file: UploadFile = File(...),
    authorization: str = Header(...),
    db: Session = Depends(get_db),  # Ajout de la session DB pour gérer la base
):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    # Vérification de l'extension du fichier
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    try:
        # Sauvegarde temporaire du fichier
        temp_file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(temp_file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        # Extraction du texte du PDF
        reader = PdfReader(temp_file_path)
        extracted_text = ""
        for page in reader.pages:
            extracted_text += page.extract_text()
        
        if not extracted_text.strip():
            raise HTTPException(status_code=400, detail="Failed to extract text from the CV")
        
        # Supprimer le fichier temporaire après extraction
        os.remove(temp_file_path)

        # Vérifier l'utilisateur et récupérer le `owner_id` via verify_user_exists
        try:
            user_info = verify_user_exists(authorization.split(" ")[1])  # Appel de la fonction
            owner_id = user_info.get("id")  # Utiliser la clé correcte pour l'ID utilisateur

            if not owner_id:
                raise HTTPException(status_code=404, detail="Owner ID not found in user profile")

            # Générer dynamiquement le champ text
            generated_text = f"{extracted_text}"  

            # Enregistrement en base
            new_cv = CV(
                text=generated_text,
                owner_id=owner_id,
                skills=None,  
                experience=None,
                education=None,
                languages=None
            )
            db.add(new_cv)
            db.commit()
            db.refresh(new_cv)
        except Exception as db_error:
            raise HTTPException(status_code=500, detail=f"Database error: {str(db_error)}")

        # Retourner cv_id et le texte extrait
        return {"cv_id": new_cv.id, "text": extracted_text}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")



@router.post("/cv/create")
def create_cv(cv_data: CVCreate, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token format"
        )

    token = authorization.split(" ")[1]

    try:
        user_info = verify_user_exists(token)
        print("User info décodée :", user_info)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token validation failed"
        )

    # Vérifiez si l'utilisateur est un candidat
    if user_info.get("role") != "candidate":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access restricted to candidates only"
        )

    owner_id = user_info.get("id")
    if not owner_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Owner ID is missing from user information"
        )

    # Vérifie si l'utilisateur a déjà un CV
    existing_cv = db.query(CV).filter(CV.owner_id == owner_id).first()
    if existing_cv:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A CV already exists for this user"
        )

    # Crée un nouveau CV
    new_cv = CV(**cv_data.dict(), owner_id=owner_id)
    db.add(new_cv)
    db.commit()
    db.refresh(new_cv)
    return new_cv


@router.post("/cv/save")
def save_cv(cv_data: CVSave, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")

    cv = db.query(CV).filter(CV.id == cv_data.id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    cv.saved = True
    db.commit()
    return {"message": "CV saved as official"}

@router.post("/cv/download")
def download_cv(cv_data: CVDownload, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")

    cv = db.query(CV).filter(CV.id == cv_data.id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")
    return {"message": "CV ready for download as PDF"}

@router.get("/cv/{id}")
def get_cv(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    print(f"Fetching CV with ID: {id}")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]

    user_info = verify_user_exists(token)
    print(f"User info from token: {user_info}")

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    print(f"Owner ID: {owner_id}")

    cv = db.query(CV).filter(CV.id == id, CV.owner_id == owner_id).first()
    if not cv:
        print(f"CV not found or unauthorized access for ID: {id}")
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    print(f"CV found: {cv}")

    # Génération dynamique du champ `text`
    cv_text = f"{cv.skills} {cv.experience} {cv.education} {cv.languages} {cv.projects or ''}".strip()

    return {
        "id": cv.id,
        "owner_id": cv.owner_id,
        "skills": cv.skills,
        "experience": cv.experience,
        "education": cv.education,
        "certifications": cv.certifications,
        "languages": cv.languages,
        "projects": cv.projects,
        "text": cv_text,  # Ajout du champ calculé
    }


@router.delete("/cv/{id}")
def delete_cv(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")

    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    
    cv = db.query(CV).filter(CV.id == id, CV.owner_id == owner_id).first()
    if not cv:
        raise HTTPException(status_code=404, detail="CV not found or access unauthorized")

    if cv.file_path and os.path.exists(cv.file_path):
        os.remove(cv.file_path)

    db.delete(cv)
    db.commit()

    return {"message": "CV successfully deleted", "cv_id": id}

@router.get("/cv/preview")
async def preview_cv(
    authorization: str = Header(...),
    db: Session = Depends(get_db)
):
    print("Authorization Header reçu :", authorization)

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")

    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "candidate":
        raise HTTPException(status_code=403, detail="Access restricted to candidates only")

    owner_id = user_info.get("id")
    cv = db.query(CV).filter(CV.owner_id == owner_id).first()

    if not cv or not cv.file_path:
        raise HTTPException(status_code=404, detail="No CV found for the user")

    return {"file_path": cv.file_path}


@router.get("/cvs", summary="Get all CVs")
def get_all_cvs(db: Session = Depends(get_db)):
   
    cvs = db.query(CV).all()
    if not cvs:
        return []
    
    # Retourne chaque CV sous forme de dictionnaire
    return [
        {
            "id": cv.id,
            "skills": cv.skills,
            "experience": cv.experience,
            "education": cv.education,
            "languages": cv.languages,
            "text": f"{cv.experience} {cv.skills} {cv.education or ''} {cv.languages or ''}"
        }
        for cv in cvs
    ]