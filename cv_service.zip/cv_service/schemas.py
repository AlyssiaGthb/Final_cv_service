from pydantic import BaseModel
from typing import Optional

class CVCreate(BaseModel):
    skills: str
    experience: str
    education: str
    certifications: Optional[str]=None
    languages: Optional[str]=None
    projects: Optional[str]=None

class CVCustomize(BaseModel):
    layout: Optional[str]=None

class CVPreview(BaseModel):
    id: int
    skills: str
    experience: str
    education: str
    certifications: Optional[str] = None
    languages: Optional[str] = None
    projects: Optional[str] = None
    layout: Optional[str] = None

class CVSave(BaseModel):
    id: int

class CVDownload(BaseModel):
    id: int

class CVUploadResponse(BaseModel):
    message: str
    cv_id: int
    file_path: str